# Media Mix Model visual-asset provenance

The production Media Mix Model application references the checked-in `client/public/logo.png` from structured data and SEO metadata. Its checked-in delivery variants are:

| Source file               | Git blob                                   | SHA-256                                                            |
| ------------------------- | ------------------------------------------ | ------------------------------------------------------------------ |
| `client/public/logo.png`  | `eab657fdcd2027eaf00eee6b3deb76f4299f1891` | `2c27180873b1c0e1f8276257dd525a65acd7dbe6d5542bed666a320b57ff6e98` |
| `client/public/logo.webp` | `70e2e53de11433700ba8703b5db74e441e3a4fd8` | `b445aca5e367b5aaea486f228547d12760f04d8f401d867e5db536391077cab1` |
| `client/public/logo.avif` | `49012fc52559480d64942cb8b3b56d5552aa5dad` | `783645ee94988356b3f9bcecc27a4fb22a4fd1f3f67b998b10eb752f8d48a4bc` |

Repository provenance was inspected without reading environment files. The PNG was introduced in Media Mix Model commit `8f8126c1d39b571471112e180dfcb3d9636b6c68` on 2025-08-11 by the repository author in “Update website assets to use the new logo.” The WebP and AVIF variants were introduced in commit `48b2e6ae67ea853aa0f9033662180c092ff45136` on 2025-08-12.

The PNG embeds C2PA data identifying `c2pa.created`, `trainedAlgorithmicMedia`, GPT-4o, ChatGPT, and an OpenAI API conversion action. This is creation provenance only. It does not establish ownership, grant a license, or grant trademark rights.

No asset-specific ownership, license, or trademark-rights declaration is checked in. The repository also has no checked-in production font binaries or font-license files: its CSS requests `JetBrains Mono` and `Work Sans` and then falls back to system fonts. Consequently the shared renderer must fail closed. It may identify these exact bytes, but must not vendor or certify the logo for production use, and must not claim production typography or no-fallback behavior until accountable asset-rights evidence and licensed font files are checked in.

## Rights status superseded on 2026-09-06

EJ White has now provided the accountable authorization in `ASSET-RIGHTS.md` for the exact PNG bytes with SHA-256 `2c27180873b1c0e1f8276257dd525a65acd7dbe6d5542bed666a320b57ff6e98`. Those exact bytes are vendored at `logos/logo.png`. The earlier statement that no asset-specific declaration was checked in is superseded for this hash only. Font certification remains unresolved.

The canonical shared package now vendors authoritative pinned Work Sans and JetBrains Mono binaries with unmodified OFL licenses in `../fonts/`; see `../fonts/FONT-PROVENANCE.md`. This supersedes the earlier missing-font-files statement. Profile hash binding and renderer no-fallback proof remain unresolved.
