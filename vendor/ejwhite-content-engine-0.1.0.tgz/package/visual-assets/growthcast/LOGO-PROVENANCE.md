# GrowthCast logo provenance

The production GrowthCast application references these checked-in logo files:

| Source file                   | Git blob                                   | SHA-256                                                            |
| ----------------------------- | ------------------------------------------ | ------------------------------------------------------------------ |
| `public/growthcast-logo.svg`  | `d1882023ccd429a2583cd6ef10f8953cac343609` | `249a969041f9f52087bdfa764320b0b44cd9d71536c5cf0b968138015eaafb9c` |
| `public/growthcast-logo.webp` | `b6b5dcb24ea4991ebcf8eac51b3d7f4a6bbfebde` | `2d8e84f163d25dc4a2addff12e5bdf8b779efafbd85c7792a76a8fb5ffc667dd` |

Repository provenance was inspected without reading environment files. Both assets were introduced in GrowthCast commit `cc5da2066ee9aae87f61b27d0b8f7155ab70f5b1` on 2026-08-11 by the repository author, in “Add upgrade lag and GrowthCast brand assets.” The application uses the SVG as its icon and the WebP in its organization metadata.

The SVG embeds a C2PA manifest identifying a `c2pa.created` action, `trainedAlgorithmicMedia`, and `fal-ai/recraft` as the software agent. That metadata is creation provenance only. It is not evidence that the repository owner owns trademark or logo rights, and it does not grant a license.

The repository’s root MIT license covers “this software and associated documentation files” but does not explicitly identify these brand assets or grant trademark rights. No asset-specific license or ownership declaration is checked in. Therefore the shared renderer must continue to fail closed: it may identify the checked-in logo and verify its bytes, but it must not certify production logo rights or vendor/use the asset as a production-ready logo until an accountable owner checks in an explicit asset-rights statement.

## Rights status superseded on 2026-09-06

EJ White has now provided the accountable authorization in `ASSET-RIGHTS.md` for the exact SVG bytes with SHA-256 `249a969041f9f52087bdfa764320b0b44cd9d71536c5cf0b968138015eaafb9c`. Those exact bytes are vendored at `logos/growthcast-logo.svg`. The earlier statement that no asset-specific declaration was checked in is superseded for this hash only. Authoritative upstream font provenance and licensing remain unresolved.
