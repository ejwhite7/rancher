# Verdant visual-asset provenance

The Verdant marketing application references the checked-in `apps/web/public/logo.svg` from its site structured data and serves it as the public organization logo.

| Source file                | Git blob                                   | SHA-256                                                            |
| -------------------------- | ------------------------------------------ | ------------------------------------------------------------------ |
| `apps/web/public/logo.svg` | `2d8f7bcfc420a730b4cc91d34dd81f40d8676579` | `daef86cb5cfecc3cb8cd56d05a8097a4af79f76839cb9eadadd0d94e3c510c9f` |

Repository provenance was inspected without reading environment files. The SVG was introduced in Verdant commit `ab80129161b466fd7d031946860251f1c4428589` on 2026-09-02 by the repository author in “feat(web): add branded blog and SEO improvements.” The source contains a lime leaf mark and the exact “Verdant Audits” wordmark. It contains no embedded license or creation-provenance metadata.

Repository history establishes where these bytes entered this repository; it does not establish ownership, grant a license, or grant trademark rights. No asset-specific ownership, license, or trademark-rights declaration is checked in. The shared renderer therefore must not vendor or certify the logo for production use until accountable rights evidence is checked in.

The logo requests Manrope 800 and 500 with Arial/sans-serif fallback. The application requests Manrope 400–800 and Inter 400–700 from Google Fonts at runtime, but the repository has no checked-in production font binaries or font-license files. A network font request is not a deterministic checked-in asset and cannot prove no-fallback rendering. Production typography and exact logo wordmark rendering remain fail-closed until the required font files and their licenses/provenance are checked in and hash-bound.

## Rights status superseded on 2026-09-06

EJ White has now provided the accountable authorization in `ASSET-RIGHTS.md` for the exact SVG bytes with SHA-256 `daef86cb5cfecc3cb8cd56d05a8097a4af79f76839cb9eadadd0d94e3c510c9f`. Those exact bytes are vendored at `logos/logo.svg`. The earlier statement that no asset-specific declaration was checked in is superseded for this hash only. Font certification remains unresolved.

The canonical shared package now vendors authoritative pinned Manrope and Inter binaries with unmodified OFL licenses in `../fonts/`; see `../fonts/FONT-PROVENANCE.md`. This supersedes the earlier missing-font-files statement. Profile hash binding, exact logo wordmark rendering, and renderer no-fallback proof remain unresolved.
