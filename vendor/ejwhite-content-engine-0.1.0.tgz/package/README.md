# `@ejwhite/content-engine`

Provider-neutral content contracts and policy runtime. Publication remains disabled unless a consumer supplies a capable matching adapter, exact-hash approval, passing QA, and explicit execution intent.

## Container-first checks

```sh
docker build --target test -t content-engine-test .
docker run --rm content-engine-test
```

The container check also packs the distributable, extracts it in isolation, imports the documented public API, and runs the packaged CLI help command.

To verify all consumer provenance locks and artifact bytes together without installing dependencies:

```sh
docker run --rm -v /Users/ejwhite/Code:/workspace:ro -w /workspace/content-engine node:22-alpine \
  node scripts/verify-consumer-compatibility.mjs \
  /workspace/media-mix-model /workspace/growthcast /workspace/verdant-marketing
```

The consumers may use different deterministic archive formats, but all locks must identify the same package version and immutable package SHA-256 identifier; each archive must match its recorded SHA-256.

## API and CLI

```ts
import {
  loadConfiguration,
  parseContract,
  validateContract,
  canonicalArticleHash,
  validateEvidence,
  validateBrief,
  validateRunManifest,
} from "@ejwhite/content-engine";
```

```sh
content-engine config validate .
content-engine contract brief ./brief.json
content-engine migrate verdant ./legacy-post.json 2026-09-04T00:00:00Z
content-engine evidence validate ./article.json ./evidence.json
content-engine article hash ./article.json
content-engine qa ./article.json ./evidence.json verdant 2026-09-04T00:00:00Z . --markdown
content-engine queue template --output ./keyword-queue.csv
content-engine queue validate ./keyword-queue.csv
content-engine queue preview ./keyword-queue.csv --output ./import-preview.json
content-engine queue import ./keyword-queue.csv --store ./queue.json --preview-hash <sha256> --operator editor@example.com --commit
content-engine queue list --store ./queue.json --brand growthcast --state candidate
content-engine queue pause|resume|cancel <queue-item-id> --store ./queue.json --operator editor@example.com
content-engine queue reschedule <queue-item-id> --store ./queue.json --operator editor@example.com --at 2026-09-06T12:00:00Z
content-engine queue run-next --store ./queue.json --brand growthcast --operator worker-1 --shadow
```

Queue imports recompute the preview from the exact CSV bytes and require `--commit`, the exact preview hash, an accountable operator, and an explicit durable store path. The local store uses serialized writers and fsync-plus-atomic-rename snapshots. Shadow `run-next` claims generation work only and cannot claim scheduled publication work. Rescheduling is restricted to publication-approved/scheduled items; imports remain candidate/brief-review only.

`createBriefingSeedUploadAdapter` is a framework-neutral authenticated `text/csv` upload boundary over the same `previewBriefingSeedCsv` and `commitBriefingSeedPreview` service used by the CLI. It authenticates before reading the body, enforces declared and streamed byte limits, MIME restrictions, a required injected rate limiter, exact preview-hash and authenticated-operator gates, and returns deterministic row diagnostics. `FixedWindowUploadRateLimiter` is process-local; multi-process deployments must inject a shared limiter. The adapter never interprets spreadsheet formats or executable content.

Briefing seeds, queue items, and immutable import receipts have strict versioned JSON Schemas and can be checked with `content-engine contract briefing-seed|queue-item|import-receipt <file>`. Unknown fields fail closed.

`rebindManifestForArticleMetadataCorrection` deterministically rebinds an existing asset manifest after an accountable correction limited to `title`, `published_at`, or `modified_at`. It verifies both article hashes and the original manifest, removes the stale OG record, preserves every non-OG binary hash/path/length, updates article identity bindings, and returns a newly hashed manifest. Callers must retain the operator authorization receipt and regenerate the OG before publication. Changes to prose, evidence, authorship, or other article fields fail closed.

Contract failures include JSON Pointer field paths. Configuration loading validates exact `1.0.0` policy inheritance and rejects profile attempts to weaken evidence or approval gates. Cross-field brief and run-manifest validators emit stable policy/profile findings without mutating inputs, including exact mappings for the canonical failing fixtures. QA includes conservative built-in advisories for generic observations and repeated cadence; consumers may add advisory-only validators.

## Immutable consumption without a registry

Pin a full commit SHA: `npm install 'git+ssh://git@HOST/OWNER/content-engine.git#FULL_SHA'`. npm runs the package's `prepare` script for a git dependency, compiling `dist/` from that exact checkout without requiring a package registry. Consumers that prohibit lifecycle scripts can clone at the full SHA, run the container check, create an immutable tarball with `npm run pack:git`, and install that artifact with `npm install ./ejwhite-content-engine-*.tgz --ignore-scripts`. A checked-in workspace/file dependency is also supported. Do not pin a mutable branch or tag where immutable provenance is required.

See `docs/architecture.md`, `docs/authoring.md`, `docs/migrations.md`, `docs/operations.md`, `docs/security.md`, `docs/policy-contract-handoff.md`, and `fixtures/README.md`. No runtime function performs network access or remote writes.

## Image generation configuration

The provider-neutral image API defaults fail closed and does not load `.env` files. Inject these standardized variables through the caller or deployment environment:

```text
GOOGLE_API_KEY=
IMAGE_GENERATION_PROVIDER=google
IMAGE_GENERATION_MODEL=gemini-3-pro-image
IMAGE_GENERATION_MAX_ATTEMPTS=3
```

`gemini-3-pro-image` is intentionally pinned; moving aliases and other model IDs are rejected. Tests use an injected mocked `fetch` and make no provider calls. Destination asset materialization and publication adapters are deferred.

## Deterministic fixture renderer

`renderHero`, `renderFixtureOg`, and `validateRenderedImage` provide dependency-free, container-stable PNG review fixtures using the procedural `Fixture Mono 5x7` test font and brand-specific geometric grammars. These APIs are explicitly non-production. `renderOg` is the canonical production entrypoint: it verifies the exact hash-bound logo, font, and OFL bytes, then returns a 1200x630 browser compositor document that loads the approved font and logo with a fail-closed fallback chain. Pinned Chromium QA verifies exact title/logo output, genuine font-byte loading, fallback detection, dimensions, crops, and deterministic hashes for all three brands.

## Asset run stages

Shared orchestration recognizes `visual-plan`, `inline-image-generation`, `hero-render`, `og-render`, `asset-validation`, and `publication-bundle` before publication preflight. Handlers remain caller-supplied and resumable; adding a stage cannot itself approve or publish. Queue template, validation, preview, durable import/list/mutation, and shadow run-next commands are local-only. Output generation refuses to overwrite files, and durable mutations require the documented explicit store/operator gates. Destination adapters remain deferred.

### Visual renderer certification

The dependency-free raster renderer is a deterministic QA fixture, not a certified production renderer. `validateRenderedImage` parses the complete PNG structure and pixel stream and deterministically checks MIME, encoded and declared dimensions, corruption/CRC, SHA-256, measured WCAG contrast, conservative crop containment, measured title bounds/minimum size, and logo clearance/collision. `certifyVisualProfile` intentionally fails closed for all three production properties until asset provenance is checked in:

- `media-mix-model`: the production app's exact `client/public/logo.png` identity, source commits, delivery variants, and GPT-4o/ChatGPT C2PA creation metadata are documented in `visual-assets/media-mix-model/ASSET-PROVENANCE.md`. C2PA and repository history grant no ownership, license, or trademark rights. CSS requests JetBrains Mono and Work Sans, but no font binaries or font-license files are checked in, so both logo use and no-fallback typography remain blocked.
- `growthcast`: the exact checked-in Manrope 4.504 and DM Mono 1.000 binaries are vendored under `visual-assets/growthcast/`, hash-checked, and documented from embedded copyright/source/version/OFL metadata. The shared `buildGrowthcastOgDocument` compositor owns the exact-title HTML, font-face declarations, dimensions, and asset identities used by browser rendering. Run the pinned browser proof with `docker run --rm -v "$PWD:/app" -w /app pi-playwright-validator:1.62.1 npm run test:browser:growthcast-fonts`; it builds the shared API, verifies every exact font response hash, `FontFaceSet` loaded status, computed family, and glyph metrics distinct from a deliberately missing fallback, and writes a review screenshot to `/tmp` inside the disposable container. The production profile remains blocked because `public/growthcast-logo.svg` has no checked-in ownership/license provenance; the compositor therefore renders a text placeholder rather than claiming the logo is cleared.
- `verdant`: the exact `apps/web/public/logo.svg` identity and source commit are documented in `visual-assets/verdant/ASSET-PROVENANCE.md`. Repository history grants no ownership, license, or trademark rights. The site requests Manrope and Inter at runtime, and the SVG wordmark requests Manrope with fallback, but no font binaries or font-license files are checked in; logo use, exact wordmark rendering, and no-fallback typography remain blocked.

Run cross-brand fixture browser QA in the pinned validator with `docker run --rm -v "$PWD:/app" -w /app pi-playwright-validator:1.62.1 npm run test:browser:visual-fixtures`. It decodes and screenshots each brand's hero, thumbnail, canonical OG, centered desktop crop, and centered mobile crop; asserts source/rendered dimensions, canonical validation, absence of browser errors, and repeated screenshot byte identity; and writes no repository fixture files.

Do not substitute system fonts, copy an asset without identity and provenance checks, or infer a license. Add the exact approved files plus their license/ownership provenance before changing a profile to production-ready. Destination-specific image upload/publication remains outside this package and is deferred.
